// package com.example.smartstockwatcher.worker
import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.smartstockwatcher.data.AppDatabase
import com.example.smartstockwatcher.data.Repo
import com.example.smartstockwatcher.net.AlphaVantageApi
import com.example.smartstockwatcher.notifications.Notifier
import com.example.smartstockwatcher.predict.Predictor
import com.example.smartstockwatcher.prefs.SecurePrefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class StockWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    companion object { const val WORK_NAME = "smart_stock_worker" }
    private val db by lazy { AppDatabase.get(ctx) }
    private val prefs by lazy { SecurePrefs(ctx) }
    private val api by lazy { AlphaVantageApi.create() }
    private val notifier by lazy { Notifier(ctx) }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val key = prefs.apiKey
        if (key.isBlank()) return@withContext Result.success() // no API key configured

        // get tickers from DB (synchronously for simplicity)
        val tickers = db.stockDao().allTickersFlow().let { /* we can't collect Flow here easily; use simple query instead in production */ emptyList<com.example.smartstockwatcher.data.TickerEntity>() }
        // For easier demo: fallback to a static list if DB not set up:
        val watch = listOf("AAPL", "MSFT", "GOOGL") // ideally fetch DB entries

        val repo = Repo(api, key)
        for (sym in watch) {
            val prices = repo.fetchRecentPrices(sym, days = 60)
            if (prices.isEmpty()) continue
            val current = prices.last()
            val prevClose = if (prices.size >= 2) prices[prices.size - 2] else prices.last()
            // thresholds: in real app read per-ticker thresholds from DB
            val buyThreshold = 0.98
            val sellThreshold = 1.02

            // buy/sell check relative to previous close
            if (current <= prevClose * buyThreshold) {
                notifier.alertBuy(sym, current)
            } else if (current >= prevClose * sellThreshold) {
                notifier.alertSell(sym, current)
            }

            // predict next price
            val forecast = Predictor.linearForecast(prices, lookback = 20)
            if (forecast != null) notifier.alertPrediction(sym, forecast)

            // combined signal -> optional stronger alert
            val signal = Predictor.combinedSignal(prices)
            if (signal > 0 && forecast != null && forecast > current * 1.01) {
                // bullish
                notifier.alertBuy(sym, current)
            } else if (signal < 0 && forecast != null && forecast < current * 0.99) {
                notifier.alertSell(sym, current)
            }
        }
        Result.success()
    }
}
