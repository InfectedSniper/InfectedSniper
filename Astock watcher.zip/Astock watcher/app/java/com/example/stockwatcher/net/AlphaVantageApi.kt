// package com.example.smartstockwatcher.net
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

interface AlphaVantageApi {
    // TIME_SERIES_DAILY adjusted (compact returns last 100 days)
    @GET("query?function=TIME_SERIES_DAILY_ADJUSTED&outputsize=compact&datatype=json")
    fun getDaily(@Query("symbol") symbol: String, @Query("apikey") key: String): Call<Map<String, Any>>

    companion object {
        fun create(): AlphaVantageApi {
            val retrofit = Retrofit.Builder()
                .baseUrl("https://www.alphavantage.co/")
                .addConverterFactory(MoshiConverterFactory.create())
                .build()
            return retrofit.create(AlphaVantageApi::class.java)
        }
    }
}
