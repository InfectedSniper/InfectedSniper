// package com.example.smartstockwatcher.notifications
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class Notifier(private val context: Context) {
    private val CH_ID = "smartstock_alerts"
    private val nm = NotificationManagerCompat.from(context)

    init { createChannel() }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CH_ID, "Stock Alerts", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "Buy / Sell signals"
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    fun alertBuy(symbol: String, price: Double) {
        val id = (System.currentTimeMillis() / 1000L % Int.MAX_VALUE).toInt()
        val notif = NotificationCompat.Builder(context, CH_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("BUY suggested: $symbol")
            .setContentText("$symbol at \$$price — price near buy threshold")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        nm.notify(id, notif)
    }

    fun alertSell(symbol: String, price: Double) {
        val id = (System.currentTimeMillis() / 1000L % Int.MAX_VALUE).toInt()
        val notif = NotificationCompat.Builder(context, CH_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("SELL suggested: $symbol")
            .setContentText("$symbol at \$$price — price reached sell threshold")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        nm.notify(id, notif)
    }

    fun alertPrediction(symbol: String, forecast: Double) {
        val id = (System.currentTimeMillis() / 1000L % Int.MAX_VALUE).toInt()
        val notif = NotificationCompat.Builder(context, CH_ID)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("Forecast for $symbol")
            .setContentText("Next price forecast: \$$forecast")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        nm.notify(id, notif)
    }
}
