// package com.example.smartstockwatcher.data
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tickers")
data class TickerEntity(
    @PrimaryKey val symbol: String,
    val buyThreshold: Double = 0.98, // default: buy when <= 98% of reference
    val sellThreshold: Double = 1.02 // default: sell when >= 102% of reference
)

data class Quote(val symbol: String, val current: Double, val previousClose: Double)
