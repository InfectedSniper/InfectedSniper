// package com.example.smartstockwatcher.data
import android.util.Log
import com.example.smartstockwatcher.net.AlphaVantageApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class Repo(private val api: AlphaVantageApi, private val apiKey: String) {
    suspend fun fetchRecentPrices(symbol: String, days: Int = 60): List<Double> = withContext(Dispatchers.IO) {
        try {
            val resp = api.getDaily(symbol, apiKey).execute()
            if (!resp.isSuccessful || resp.body() == null) return@withContext emptyList()
            val body = resp.body()!!
            // body contains keys: "Meta Data" and "Time Series (Daily)"
            val timeSeriesKey = body.keys.firstOrNull { it.contains("Time Series") } ?: return@withContext emptyList()
            val ts = body[timeSeriesKey] as? Map<*, *> ?: return@withContext emptyList()
            val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
            val prices = ts.entries.mapNotNull { entry ->
                val dateStr = entry.key as? String ?: return@mapNotNull null
                val dayMap = entry.value as? Map<*, *> ?: return@mapNotNull null
                val closeStr = (dayMap["4. close"] ?: dayMap["4. close"])?.toString() ?: return@mapNotNull null
                val close = closeStr.toDoubleOrNull() ?: return@mapNotNull null
                Pair(LocalDate.parse(dateStr, formatter), close)
            }.sortedBy { it.first }.map { it.second }
            // take last `days` entries
            if (prices.size <= days) prices else prices.takeLast(days)
        } catch (e: Exception) {
            Log.e("Repo", "fetch error", e)
            emptyList()
        }
    }
}
