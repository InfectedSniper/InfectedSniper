// package com.example.smartstockwatcher.data
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface StockDao {
    @Query("SELECT * FROM tickers")
    fun allTickersFlow(): Flow<List<TickerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(ticker: TickerEntity)

    @Query("DELETE FROM tickers WHERE symbol = :symbol")
    suspend fun delete(symbol: String)
}
