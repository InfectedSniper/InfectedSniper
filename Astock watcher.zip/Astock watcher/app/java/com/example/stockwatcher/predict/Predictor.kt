// package com.example.smartstockwatcher.predict
import kotlin.math.pow
import kotlin.math.round

object Predictor {
    // Simple moving average of last n items
    fun sma(prices: List<Double>, n: Int): Double? {
        if (prices.size < n) return null
        return prices.takeLast(n).average()
    }

    // Exponential moving average with smoothing alpha
    fun ema(prices: List<Double>, period: Int): Double? {
        if (prices.isEmpty()) return null
        val k = 2.0 / (period + 1)
        var ema = prices.first()
        for (p in prices.drop(1)) {
            ema = p * k + ema * (1 - k)
        }
        return ema
    }

    // Linear regression to forecast next price (simple least-squares on equally spaced x=0..n-1)
    fun linearForecast(prices: List<Double>, lookback: Int = 10): Double? {
        val pts = prices.takeLast(lookback)
        if (pts.size < 3) return null
        val n = pts.size
        val xMean = (0 until n).average()
        val yMean = pts.average()
        var num = 0.0
        var den = 0.0
        for (i in 0 until n) {
            num += (i - xMean) * (pts[i] - yMean)
            den += (i - xMean).pow(2)
        }
        val slope = if (den == 0.0) 0.0 else num / den
        val intercept = yMean - slope * xMean
        val forecast = intercept + slope * n // predict next x = n
        return round(forecast * 100.0) / 100.0
    }

    // Combine predictors into a single "confidence" signal: +1 strong upward forecast, -1 strong downward
    fun combinedSignal(prices: List<Double>): Int {
        val lr = linearForecast(prices, 15) ?: return 0
        val smaShort = sma(prices, 5) ?: lr
        val smaLong = sma(prices, 20) ?: smaShort
        val score = listOf(
            if (lr > prices.last() * 1.01) 1 else 0,
            if (smaShort > smaLong) 1 else 0
        ).sum()
        return when (score) { 2 -> 1; 1 -> 0; else -> -1 }
    }
}
