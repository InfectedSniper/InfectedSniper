// package com.example.smartstockwatcher
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.work.*
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private lateinit var prefs: com.example.smartstockwatcher.prefs.SecurePrefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = com.example.smartstockwatcher.prefs.SecurePrefs(this)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppContent()
                }
            }
        }
    }

    @Composable
    fun AppContent() {
        var apiKey by remember { mutableStateOf(prefs.apiKey) }
        var newTicker by remember { mutableStateOf("") }

        Column(modifier = Modifier.padding(16.dp)) {
            OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("AlphaVantage API Key") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = {
                prefs.apiKey = apiKey
                Toast.makeText(this@MainActivity, "API key saved", Toast.LENGTH_SHORT).show()
            }) { Text("Save API Key") }

            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(value = newTicker, onValueChange = { newTicker = it }, label = { Text("Add ticker (e.g. AAPL)") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
            Row {
                Button(onClick = {
                    // TODO: persist ticker to DB
                    Toast.makeText(this@MainActivity, "Ticker add (not implemented in demo)", Toast.LENGTH_SHORT).show()
                }) { Text("Add Ticker") }
                Spacer(modifier = Modifier.width(8.dp))
                Button(onClick = { scheduleWork(); Toast.makeText(this@MainActivity, "Worker scheduled every 15min", Toast.LENGTH_SHORT).show() }) { Text("Start Watching") }
                Spacer(modifier = Modifier.width(8.dp))
                Button(onClick = { WorkManager.getInstance(this@MainActivity).cancelUniqueWork(com.example.smartstockwatcher.worker.StockWorker.WORK_NAME); Toast.makeText(this@MainActivity, "Stopped", Toast.LENGTH_SHORT).show() }) { Text("Stop") }
            }
        }
    }

    private fun scheduleWork() {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val req = PeriodicWorkRequestBuilder<com.example.smartstockwatcher.worker.StockWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(com.example.smartstockwatcher.worker.StockWorker.WORK_NAME, ExistingPeriodicWorkPolicy.REPLACE, req)
    }
}
